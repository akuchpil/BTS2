<?php
class Conf{
	
	static $debug = 1; 

	static $databases = array(

		'default' => array(
			'host'		=> 'localhost',
			'database'	=> '',
			'login'		=> 'root',
			'password'	=> ''
		)
	);


}

Trace::connect('','test/index');
Trace::connect('test/:slug-:id.html','test/index/id:([0-9]+)/slug:([a-z0-9\-]+)');
?>